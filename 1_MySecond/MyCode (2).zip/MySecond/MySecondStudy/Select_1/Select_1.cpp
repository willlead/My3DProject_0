// Select_1.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#include <stdio.h>
#include <vector>
#include <list>
#include "tprotocol.h"

#pragma comment (lib, "ws2_32.lib")
using namespace std;


struct TUser
{
	bool bConnect;
	SOCKET sock;
	SOCKADDR_IN ClientAddr;
};

std::list<TUser*> g_UserList;
CRITICAL_SECTION g_crit;

int main()
{
	InitializeCriticalSection(&g_crit);

	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { return 0; }
	SOCKET listensock;
	listensock = socket(AF_INET, SOCK_STREAM, 0);

	SOCKADDR_IN sa;
	sa.sin_family = AF_INET;
	sa.sin_port = htons(10000);
	sa.sin_addr.s_addr = htonl(INADDR_ANY);
	int iRet = bind(listensock, (SOCKADDR*)&sa, sizeof(sa));
	if(iRet == SOCKET_ERROR)


    return 0;
}

