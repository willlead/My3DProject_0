#pragma once
class TSelect
{
public:
	TSelect();
	virtual ~TSelect();
};

