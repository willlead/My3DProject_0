#include "stdafx.h"
#include "TSelect.h"


TSelect::TSelect()
{
}


TSelect::~TSelect()
{
}
