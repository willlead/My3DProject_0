#pragma once
class WEnemey
{
public:
	WEnemey();
	virtual ~WEnemey();
};

