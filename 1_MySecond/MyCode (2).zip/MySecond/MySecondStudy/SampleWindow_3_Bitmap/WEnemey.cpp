#include "WEnemey.h"



WEnemey::WEnemey()
{
}


WEnemey::~WEnemey()
{
}
