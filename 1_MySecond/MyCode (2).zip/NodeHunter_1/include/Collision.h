#pragma once
#include "Std.h"
struct WSphere
{
	POINT ptCenter;
	float fRadius;
};
class Collision
{
public:
	friend bool     RectInPt(RECT& rt, POINT& pt);
	friend bool     RectInPt(WRect& rt, POINT& pt);
	friend bool     RectInRect(RECT& rtDesk, RECT& rtSrc);
	friend bool		SphereInSphere(WSphere& s1, WSphere& s2);
	friend bool		SphereInSphere(RECT& s1, RECT& s2);
	friend bool     RectInRect(WRect& s1, WRect& s2);
public:
	Collision();
	virtual ~Collision();
};

