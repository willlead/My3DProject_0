#pragma once
#include "LinkedList.h"

template <class W>
class HashTable
{
public:
	LinkedList<W>*		m_pArray;
	int					m_iLength;
	int					Hash(TCHAR* pName);
	void				Insert(W* newItem);
	W*					Find(TCHAR* pszName);
public:
	HashTable(int iLength = 20);
	~HashTable();
};
template < class W >
int	HashTable<W>::Hash(TCHAR* pName)
{
	int iKey = 5381;
	int c;
	size_t hash = 0x811c9dc5;
	while (c = *pName++)
	{
		hash ^= c;
		hash *= 0x01000193;
	}
	/*int c;
	while (c = *pName++)
	{
	iKey = ((iKey << 5) + iKey) + c;
	}*/
	/*int iValue = 0;
	int iLen = _tcslen(pName);
	for (int i = 0; i < iLen; i++)
	{
	iValue += pName[i];
	}
	int iKey = (iValue * iValue) % m_iLength;*/
	return hash % m_iLength;
}
template < class W >
void HashTable<W>::Insert(W* newItem)
{
	int iIndex = Hash(newItem->m_szName);
	m_pArray[iIndex].AddLink(newItem);
};
template < class W >
W* HashTable<W>::Find(TCHAR* pszName)
{
	int iIndex = Hash(pszName);
	return m_pArray[iIndex].GetData(pszName);
};

template < class W >
HashTable<W>::HashTable(int iLength)
{
	m_pArray = new LinkedList<W>[iLength];
	m_iLength = iLength;
}
template < class W >
HashTable<W>::~HashTable()
{
	delete[] m_pArray;
}