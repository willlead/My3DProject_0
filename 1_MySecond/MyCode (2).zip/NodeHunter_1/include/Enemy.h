#pragma once
class Enemy
{
public:
	Enemy();
	virtual ~Enemy();
};

