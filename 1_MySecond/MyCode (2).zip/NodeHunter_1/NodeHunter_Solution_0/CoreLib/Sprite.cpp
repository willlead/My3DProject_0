#include "Sprite.h"
#include "Sys.h"
void   Sprite::SetRectArray(
	vector<RECT> rtList,
	float fLifeTime)
{
	for (int iList = 0; iList < rtList.size();
	iList++)
	{
		m_rtList.push_back(rtList[iList]);
	}
	m_fLifeTime = fLifeTime;
	m_iNumFrame = m_rtList.size();
	m_iCurFrame = 0;
}
void Sprite::SetSpeed(float fSpeed)
{
	m_fLifeTime = fSpeed;
	m_fSecPerRender = m_fLifeTime / m_iNumFrame;
}
bool Sprite::Frame()
{
	m_fTimer += g_fSecondPerFrame;
	if (m_fTimer > m_fSecPerRender)
	{
		if (++m_iCurFrame >= m_iNumFrame)
		{
			m_iCurFrame = 0;
		}
		m_fTimer = 0.0f;
	}
	return true;
}
bool Sprite::Render()
{
	return true;
}
bool Sprite::Release()
{
	return true;
}
Sprite::Sprite()
{
	m_fSecPerRender = 0.0f;
	m_iSpriteID = 0;
	m_iCurFrame = 0;
	m_fTimer = 0.0f;
}


Sprite::~Sprite()
{
}
