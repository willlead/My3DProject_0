#include "BitmapMgr.h"

template< typename W >
void SwapPoint(W* a, W* b)
{
	a->m_pNext = b;
	b->m_pPrev = a;
}
Node<Bitmap> * BitmapMgr::Swap(
	Node<Bitmap>* a, Node<Bitmap>* b)
{
	Node<Bitmap> * aPrev = a->m_pPrev;
	Node<Bitmap> * aNext = a->m_pNext;
	Node<Bitmap> * bPrev = b->m_pPrev;
	Node<Bitmap> * bNext = b->m_pNext;

	// 1�� Haed <-> b
	if (aPrev != NULL) {
		SwapPoint(aPrev, b);
	}
	else {
		m_List.m_pHead = b;
		b->m_pPrev = NULL;
	}
	// b <-> a
	if (aNext != b)
	{
		SwapPoint(b, aNext);
		// a -> c -> b
		if (aNext->m_pNext == b)	SwapPoint(aNext, a);
		else						SwapPoint(bPrev, a);
	}
	else // b <-> a
	{
		SwapPoint(b, a);
		a->m_pNext = bNext;
		if (bNext != NULL) bNext->m_pPrev = a;
	}
	// a-> c -> b ->d
	if (bNext != NULL)  SwapPoint(a, bNext);
	else				a->m_pNext = NULL;

	if (aNext == b) return a;
	return aNext;
}
// iCnt ���� ���� �л��� �����ϰ� ����.
Bitmap*   BitmapMgr::Load(TCHAR* pszLoadFile)
{
	TCHAR Drive[MAX_PATH] = { 0, };
	TCHAR Dir[MAX_PATH] = { 0, };
	TCHAR Name[MAX_PATH] = { 0, };
	TCHAR Ext[MAX_PATH] = { 0, };
	TCHAR SaveName[MAX_PATH] = { 0, };
	_tsplitpath_s(pszLoadFile, Drive, Dir, Name, Ext);
	_stprintf_s(SaveName, _T("%s%s"), Name, Ext);
	Bitmap* pBitmap = NULL;
	pBitmap = m_List.GetData(SaveName);
	if (pBitmap)
	{
		return pBitmap;
	}

	Bitmap* pData = new Bitmap;
	if (pData->Load(pszLoadFile))
	{
		m_Hash.Insert(pData);
		m_List.AddLink(pData);
		//return m_List.GetData(pData->m_szName);
		return m_Hash.Find(SaveName);
	}
	return NULL;
}

Bitmap*  BitmapMgr::Find(int iIndex)
{
	for (Node<Bitmap>* pLink = m_List.m_pHead;
	pLink != NULL;
		pLink = pLink->m_pNext)
	{
		Bitmap* pData = pLink->m_pData;
		if (pData->m_iIndex == iIndex)
		{
			return pData;
		}
	}
	return NULL;
}
Bitmap*  BitmapMgr::Find(TCHAR* pszName)
{
	int iIndex = this->m_Hash.Hash(pszName);
	if (iIndex >= m_Hash.m_iLength) return NULL;
	return m_Hash.m_pArray[iIndex].GetData(pszName);
}
void    BitmapMgr::ShowData()
{
	/*for (TNode<TBitmap>* pLink = m_List.m_pHead;
	pLink != NULL;
	pLink = pLink->m_pNext)
	{
	TBitmap* pData = pLink->m_pData;
	wcout << pData->m_iIndex << " "
	<< pData->m_szName << " "
	<< pData->m_Subject.m_iKor << " "
	<< pData->m_Subject.m_iEng << " "
	<< pData->m_Subject.m_iMat << " "
	<< pData->m_iTotal << " "
	<< endl;
	}*/
}
void    BitmapMgr::ShowData(Bitmap* pStd)
{
	/*if (pStd == NULL) return;
	wcout << " ========= " << pStd->m_iIndex << " "
	<< pStd->m_szName << " "
	<< pStd->m_Subject.m_iKor << " "
	<< pStd->m_Subject.m_iEng << " "
	<< pStd->m_Subject.m_iMat << " "
	<< pStd->m_iTotal << " "
	<< endl;*/
}
void    BitmapMgr::Sort(bool bUp)
{
	//TNode<TBitmap>* pNodeSrc = m_List.GetHead();
	//while (pNodeSrc && pNodeSrc->m_pNext)
	//{
	//	TNode<TBitmap>* pNodeSwap = pNodeSrc;
	//	TBitmap* pSrcStudent = pNodeSwap->m_pData;
	//	for (TNode<TBitmap>* pNodeDesk = pNodeSrc->m_pNext;
	//	pNodeDesk != NULL;
	//		pNodeDesk = pNodeDesk->m_pNext)
	//	{
	//		TBitmap* pDeskStudent = pNodeDesk->m_pData;
	//		if (pNodeSwap->m_pData->m_iTotal > pDeskStudent->m_iTotal)
	//		{
	//			pNodeSwap = pNodeDesk;
	//		}
	//	}
	//	if (pNodeSrc != pNodeSwap)
	//	{
	//		pNodeSrc = Swap(pNodeSrc, pNodeSwap);
	//	}
	//	else
	//	{
	//		pNodeSrc = pNodeSrc->m_pNext;
	//	}
	//}
}
void    BitmapMgr::Release()
{
	m_List.Release();
}



BitmapMgr::BitmapMgr()
{
}


BitmapMgr::~BitmapMgr()
{
}
