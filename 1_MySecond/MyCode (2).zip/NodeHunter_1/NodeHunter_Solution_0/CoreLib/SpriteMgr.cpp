#include "SpriteMgr.h"

INT  SpriteMgr::Load(TCHAR* pszName,
	TCHAR* pszColorFile,
	TCHAR* pszMaskFile)
{
	// �ߺ�üũ
	Sprite* pSprite = new Sprite;
	if (!pSprite->Load(pszColorFile, pszMaskFile))
	{
		delete pSprite;
		return 0;
	}
	pSprite->m_szName = pszName;
	m_mapList.insert(make_pair(++m_iKey, pSprite));
	pSprite->m_iSpriteID = m_iKey;
	return m_iKey;
}
Sprite*  SpriteMgr::Find(INT iKey)
{
	std::map<INT, Sprite*>::iterator itor =
		m_mapList.find(iKey);
	if (itor == m_mapList.end()) return NULL;
	//TSprite* pSprite = (*itor).first; // key
	Sprite* pSprite = (*itor).second;// data
	return pSprite;
}


SpriteMgr::SpriteMgr()
{
}


SpriteMgr::~SpriteMgr()
{
}
