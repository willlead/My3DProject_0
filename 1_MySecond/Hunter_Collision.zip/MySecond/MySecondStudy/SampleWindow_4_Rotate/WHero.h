#pragma once
class WHero
{
public:
	WHero();
	virtual ~WHero();
};

