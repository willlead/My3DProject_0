#pragma once
#include <Windows.h>
extern HWND g_hWnd;
extern float g_fSecondPerFrame;