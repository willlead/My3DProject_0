#include "WHero.h"



WHero::WHero()
{
}


WHero::~WHero()
{
}
