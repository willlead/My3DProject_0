#include "WEnemy.h"



WEnemy::WEnemy()
{
}


WEnemy::~WEnemy()
{
}
