#include "WSprite.h"



WSprite::WSprite()
{
}


WSprite::~WSprite()
{
}
