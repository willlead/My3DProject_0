#include "WSpriteMgr.h"

WSprite * WSpriteMgr::Load(TCHAR* pszLoadFile) {

	return NULL;
}
WSprite * WSpriteMgr::Find(INT iKey) {
	return NULL;
}

WSpriteMgr::WSpriteMgr()
{
	m_iKey = 0;
}


WSpriteMgr::~WSpriteMgr()
{
}
