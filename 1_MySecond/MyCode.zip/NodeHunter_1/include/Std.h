#pragma once
#include <windows.h>
#include <tchar.h>
#include <vector>
#include <map>
#include <list>
#include <string>
using namespace std;

struct WRect
{
	int   x, y;
	int   w, h;
};

struct NodeType
{
	int index;
	int data;
	WRect rect;
};

template <class W> class WSingleton
{
public:
	static W& GetInstance()
	{
		static W theSingleton;
		return theSingleton;
	}
};