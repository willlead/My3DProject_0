#pragma once
#include "Window.h"
#include "Timer.h"
#include "Input.h"
#include "Bitmap.h"
class Core : public Window
{
public:
	HDC			m_hScreenDC;  // �� 1 DC => ���
							  // �� 2 DC=> ����
	HDC			m_hOffScreenDC;
	// �� 2 DC�� ��Ʈ��
	HBITMAP		m_hOffScreenBitmap;
public:
	Timer     m_Timer;
	Input     m_Input;
	Bitmap	  m_Bitmap;
public:
	virtual bool     Init(); // �ʱ�ȭ
	virtual bool     Frame();// ���
	virtual bool     PreRender();// ��ο�
	virtual bool     Render();// ��ο�
	virtual bool     PostRender();// ��ο�
	virtual bool     Release();// ����, �Ҹ�
	virtual void     DebugString();
	virtual void     MsgEvent(MSG msg);
public:
	bool Run();
	bool GameRun();
	bool GameInit();
	bool GameFrame();
	bool GameRender();
	bool GameRelease();
public:
	Core();
	virtual ~Core();
};

