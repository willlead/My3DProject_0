#pragma once
#include "Bitmap.h"
#include "Std.h"
class Shape
{
public:
	Bitmap*   m_pColor;
	Bitmap*   m_pMask;
	RECT     m_rtDraw;
	POINT    m_Position;
public:
	virtual bool	   Load(TCHAR* pColor,
		TCHAR* pMask);
	virtual bool   Init();
	virtual bool   Frame();
	virtual bool   Render();
	virtual bool   Release();
public:
	Shape();
	virtual ~Shape();
};

