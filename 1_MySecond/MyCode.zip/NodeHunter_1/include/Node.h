#pragma once
#include <iostream>
#include <tchar.h>
template < class W >
class Node
{
public:
	W*		m_pData;
	Node*  m_pNext;
	Node*  m_pPrev;
public:
	Node();
	~Node();
};
template < class W>
Node<W>::Node()
{
	m_pData = NULL;
	m_pNext = NULL;
	m_pPrev = NULL;
}
template < class W>
Node<W>::~Node()
{
	delete m_pData;
}