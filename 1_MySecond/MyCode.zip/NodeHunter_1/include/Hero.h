#pragma once
class Hero
{
public:
	Hero();
	virtual ~Hero();
};

