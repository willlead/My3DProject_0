#pragma once
#include "Sprite.h"
#include <map>	
class SpriteMgr : public WSingleton<SpriteMgr>
{
private:
	INT			m_iKey;
	friend class WSingleton<SpriteMgr>;
	std::map<INT, Sprite*>   m_mapList;
	INT   Load(TCHAR* pszName,
		TCHAR* pszColorFile,
		TCHAR* pszMaskFile);
	Sprite*   Find(INT iKey);
public:
	SpriteMgr();
	virtual ~SpriteMgr();
};
#define I_Sprite TSpriteMgr::GetInstance()
