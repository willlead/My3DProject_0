#pragma once
#include "HashTable.h"
#include "Bitmap.h"
class BitmapMgr : public WSingleton<BitmapMgr>
{
public:
	friend class WSingleton<BitmapMgr>;
	/*static TBitmapMgr& GetInstance()
	{
	static TBitmapMgr  mgr;
	return mgr;
	}*/
public:
	LinkedList<Bitmap>   m_List;
	HashTable<Bitmap>    m_Hash;
private:
	LinkedList<Bitmap>   m_InitList;
public:
	Bitmap*  Load(TCHAR* pszLoadFile);
	Bitmap*  Find(int iIndex);
	void    Sort(bool bUp = true);
	void    Release();
	void    ShowData();
	void    ShowData(Bitmap* pStd);
	void    Delete(int iIndex) {};
	void    Delete(Bitmap* iData) {};
	Node<Bitmap> * Swap(
		Node<Bitmap>* a,
		Node<Bitmap>* b);
	Bitmap*  Find(TCHAR* pszName);
public:
	BitmapMgr();
	virtual ~BitmapMgr();
};
#define I_BitmapMgr BitmapMgr::GetInstance()
