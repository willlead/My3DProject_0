#include "Enemy.h"



Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}
