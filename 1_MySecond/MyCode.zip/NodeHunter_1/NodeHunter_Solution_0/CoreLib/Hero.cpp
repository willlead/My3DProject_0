#include "Hero.h"



Hero::Hero()
{
}


Hero::~Hero()
{
}
