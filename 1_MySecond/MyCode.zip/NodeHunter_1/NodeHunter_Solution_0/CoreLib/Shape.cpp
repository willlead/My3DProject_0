#include "Shape.h"
#include "BitmapMgr.h"
#include "Sys.h"
bool Shape::Load(TCHAR* pColor, TCHAR* pMask)
{
	m_pColor = I_BitmapMgr.Load(pColor);
	m_pMask = I_BitmapMgr.Load(pMask);
	return true;
}
bool Shape::Init()
{
	return true;
}
bool Shape::Frame()
{
	return true;
}
bool Shape::Release()
{
	return true;
}
bool Shape::Render()
{
	BitBlt(g_hOffScreenDC,
		m_Position.x,
		m_Position.y,
		m_rtDraw.right,
		m_rtDraw.bottom,
		m_pMask->m_hMemDC,
		m_rtDraw.left,
		m_rtDraw.top, SRCAND);

	BitBlt(g_hOffScreenDC, m_Position.x,
		m_Position.y,
		m_rtDraw.right,
		m_rtDraw.bottom,
		m_pColor->m_hMemDC,
		m_rtDraw.left,
		m_rtDraw.top, SRCINVERT);

	BitBlt(g_hOffScreenDC, m_Position.x,
		m_Position.y,
		m_rtDraw.right,
		m_rtDraw.bottom,
		m_pMask->m_hMemDC,
		m_rtDraw.left,
		m_rtDraw.top, SRCINVERT);
	return true;
}

Shape::Shape()
{
}


Shape::~Shape()
{
}
