#pragma once
#include "Core.h"
class Sample : public Core
{
	// Node =================================================
//public:
//	Node m_Node;
public:
	Bitmap    m_BackGround;
	Bitmap    m_HeroColorBitmap;
	Bitmap    m_HeroMaskBitmap;
	Bitmap    m_MobColorBitmap;
	Bitmap    m_MobMaskBitmap;

	HBRUSH	   m_back;

	HDC  m_hMaskMemDC;
	HDC  m_hColorMemDC;
	HDC  m_RotationBitmapDC;
	Bitmap    m_Bitmap;

	typedef std::vector<RECT>  SPRITE_ARRAY;
	//RECT **m_SpriteList;
	std::vector<SPRITE_ARRAY>  m_SpriteList;

	float m_fSecPerRender;
	int   m_iSpriteID;
	int   m_iFrame;
	float m_fTimer;
	float m_fLifeTime;

public:
	bool LoadSprite(TCHAR* pFileName);
	void SetSprite(int iIndex, float fLifeTime = 1.0f);
	bool DrawBackGround();
	void DrawObject();

public:
	bool Init();
	bool Frame();
	bool Render();
	bool Release();
public:
	Sample();
	virtual ~Sample();
};

