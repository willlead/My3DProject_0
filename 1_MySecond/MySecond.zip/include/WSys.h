#pragma once
#include <Windows.h>
extern HWND g_hWnd;
extern float g_fSecondPerFrame;
extern HINSTANCE g_hInstance;
extern HDC		g_hScreenDC;
extern HDC		g_hOffScreenDC;