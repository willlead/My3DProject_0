#include "WObject.h"



bool      WObject::Load(HDC hScreenDC,
	HDC hOffScreenDC,
	TCHAR* pFileName)
{
	
	return true;
}

bool    WObject::Init() {
	return true;
}
bool    WObject::Frame() {
	return true;
}
bool    WObject::Render() {
	return true;
}
bool    WObject::Release() {
	return true;
}


WObject::WObject()
{
}


WObject::~WObject()
{
}
