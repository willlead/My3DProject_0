#pragma once
#include "WStd.h"
class WSprite
{
public:
	WSprite();
	virtual ~WSprite();
};

