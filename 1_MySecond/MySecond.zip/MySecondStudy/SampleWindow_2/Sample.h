#pragma once
#include "WCore.h"	
class Sample : public WCore
{
public:
	Sample();
	virtual ~Sample();
};

