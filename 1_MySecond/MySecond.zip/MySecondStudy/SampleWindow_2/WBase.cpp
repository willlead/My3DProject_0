#include "WBase.h"



WBase::WBase()
{
}


WBase::~WBase()
{
}
