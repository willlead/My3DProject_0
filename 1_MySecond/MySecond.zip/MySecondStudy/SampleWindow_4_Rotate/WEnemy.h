#pragma once
class WEnemy
{
public:
	WEnemy();
	virtual ~WEnemy();
};

